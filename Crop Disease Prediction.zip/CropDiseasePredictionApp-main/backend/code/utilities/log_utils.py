import logging
from code.config import app_config


def get_logger():
    """Returns Common Logger"""
    return logging.getLogger()
